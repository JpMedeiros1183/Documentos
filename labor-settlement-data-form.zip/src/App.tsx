import { useState, useEffect } from 'react';
import Header from './components/Header';
import ActionBar from './components/ActionBar';
import SecaoEmpregador from './components/sections/SecaoEmpregador';
import SecaoEmpregado from './components/sections/SecaoEmpregado';
import SecaoContrato from './components/sections/SecaoContrato';
import SecaoRemuneracao from './components/sections/SecaoRemuneracao';
import SecaoAtividadeRural from './components/sections/SecaoAtividadeRural';
import SecaoFerias from './components/sections/SecaoFerias';
import SecaoObservacoes from './components/sections/SecaoObservacoes';
import { FormData } from './types/formTypes';
import { initialFormData } from './utils/initialFormData';

const STORAGE_KEY = 'ma_rescisao_form_data';

function App() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [hasSavedData, setHasSavedData] = useState(false);
  const [savedBanner, setSavedBanner] = useState(false);
  const [activeSection, setActiveSection] = useState(0);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) setHasSavedData(true);
  }, []);

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
    setHasSavedData(true);
    setSavedBanner(true);
    setTimeout(() => setSavedBanner(false), 3000);
  };

  const handleLoad = () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setFormData(JSON.parse(saved));
    }
  };

  const handleClear = () => {
    if (window.confirm('Deseja limpar todos os dados do formulário? Esta ação não pode ser desfeita.')) {
      setFormData(initialFormData);
    }
  };

  const updateEmpregador = (field: keyof FormData['empregador'], value: string) => {
    setFormData(prev => ({ ...prev, empregador: { ...prev.empregador, [field]: value } }));
  };

  const updateEmpregado = (field: keyof FormData['empregado'], value: string) => {
    setFormData(prev => ({ ...prev, empregado: { ...prev.empregado, [field]: value } }));
  };

  const updateContrato = (field: keyof FormData['contrato'], value: string) => {
    setFormData(prev => ({ ...prev, contrato: { ...prev.contrato, [field]: value } }));
  };

  const updateRemuneracao = (field: keyof FormData['remuneracao'], value: string | boolean) => {
    setFormData(prev => ({ ...prev, remuneracao: { ...prev.remuneracao, [field]: value } }));
  };

  const updateAtividadeRural = (field: keyof FormData['atividadeRural'], value: string | boolean) => {
    setFormData(prev => ({ ...prev, atividadeRural: { ...prev.atividadeRural, [field]: value } }));
  };

  const updateFerias = (field: keyof FormData['ferias'], value: string | boolean) => {
    setFormData(prev => ({ ...prev, ferias: { ...prev.ferias, [field]: value } }));
  };

  const sections = [
    { id: 0, label: 'Empregadora', icon: '👩‍🌾' },
    { id: 1, label: 'Empregado', icon: '👨‍🌾' },
    { id: 2, label: 'Contrato', icon: '📋' },
    { id: 3, label: 'Remuneração', icon: '💰' },
    { id: 4, label: 'Atividades', icon: '🐄' },
    { id: 5, label: 'Férias', icon: '🌴' },
    { id: 6, label: 'Observações', icon: '📝' },
  ];

  const scrollToSection = (idx: number) => {
    setActiveSection(idx);
    const el = document.getElementById(`section-${idx}`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-gray-100" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Header />
      <ActionBar
        onSave={handleSave}
        onLoad={handleLoad}
        onClear={handleClear}
        hasSavedData={hasSavedData}
        empregadorTelefone={formData.empregador.telefone}
        empregadoNome={formData.empregado.nomeCompleto}
      />

      {/* Saved Banner */}
      {savedBanner && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-green-600 text-white px-6 py-3 rounded-xl shadow-lg flex items-center gap-2 text-sm font-semibold animate-bounce">
          ✅ Dados salvos com sucesso no dispositivo!
        </div>
      )}

      {/* Navigation tabs */}
      <div className="bg-white border-b border-gray-200 sticky top-[57px] z-40 shadow-sm">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex overflow-x-auto gap-0 scrollbar-hide">
            {sections.map((sec) => (
              <button
                key={sec.id}
                onClick={() => scrollToSection(sec.id)}
                className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all ${
                  activeSection === sec.id
                    ? 'border-red-700 text-red-700 bg-red-50'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <span>{sec.icon}</span>
                <span className="hidden sm:inline">{sec.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        {/* Info card */}
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white rounded-2xl p-5 mb-6 flex items-start gap-4">
          <span className="text-3xl flex-shrink-0">⚖️</span>
          <div>
            <h3 className="font-bold text-lg mb-1" style={{ fontFamily: 'Merriweather, serif' }}>
              Ficha de Dados para Rescisão de Contrato de Trabalho Rural
            </h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Preencha todos os campos com atenção. Os dados coletados serão utilizados pelo escritório{' '}
              <strong className="text-red-400">Medeiros & Albuquerque Advogados</strong> para calcular as verbas rescisórias,
              elaborar o acordo entre as partes e protocolar o pedido de homologação na{' '}
              <strong className="text-red-400">Justiça do Trabalho</strong>. Campos com <span className="text-red-400">*</span> são obrigatórios.
            </p>
          </div>
        </div>

        {/* PDF Content area */}
        <div id="pdf-content">
          {/* PDF Header for print */}
          <div className="hidden-in-screen bg-gray-900 text-white p-6 rounded-t-2xl mb-0 print-header" style={{ display: 'none' }}>
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-xl font-bold" style={{ fontFamily: 'Merriweather, serif' }}>Medeiros & Albuquerque Advogados</h1>
                <p className="text-red-400 text-sm">Ficha de Dados – Rescisão de Contrato de Trabalho Rural</p>
              </div>
              <div className="text-right text-sm text-gray-300">
                <p>medeirosealbuquerqueadv@gmail.com</p>
                <p>84-998226048 | 84-988510995</p>
              </div>
            </div>
          </div>

          <div id="section-0"><SecaoEmpregador data={formData.empregador} onChange={updateEmpregador} /></div>
          <div id="section-1"><SecaoEmpregado data={formData.empregado} onChange={updateEmpregado} /></div>
          <div id="section-2"><SecaoContrato data={formData.contrato} onChange={updateContrato} /></div>
          <div id="section-3"><SecaoRemuneracao data={formData.remuneracao} onChange={updateRemuneracao} /></div>
          <div id="section-4"><SecaoAtividadeRural data={formData.atividadeRural} onChange={updateAtividadeRural} /></div>
          <div id="section-5"><SecaoFerias data={formData.ferias} onChange={updateFerias} /></div>
          <div id="section-6">
            <SecaoObservacoes
              observacoes={formData.observacoesGerais}
              dataPreenchimento={formData.dataPreenchimento}
              onChangeObservacoes={(v) => setFormData(prev => ({ ...prev, observacoesGerais: v }))}
              onChangeData={(v) => setFormData(prev => ({ ...prev, dataPreenchimento: v }))}
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="text-center mb-6">
            <h3 className="text-lg font-bold text-gray-800 mb-2" style={{ fontFamily: 'Merriweather, serif' }}>
              Formulário Concluído?
            </h3>
            <p className="text-gray-500 text-sm">
              Após preencher todos os dados, salve o arquivo PDF no seu dispositivo e envie ao escritório pelo WhatsApp.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={handleSave}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gray-800 text-white font-semibold hover:bg-gray-700 transition-colors"
            >
              💾 Salvar Dados no Dispositivo
            </button>
            <button
              onClick={async () => {
                const { downloadPDF } = await import('./utils/generatePdf');
                const fileName = `Rescisao_${formData.empregado.nomeCompleto.replace(/\s+/g, '_') || 'Empregado'}_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`;
                await downloadPDF('pdf-content', fileName);
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-red-700 text-white font-semibold hover:bg-red-600 transition-colors"
            >
              📄 Baixar PDF
            </button>
            <button
              onClick={async () => {
                const { shareViaWhatsApp } = await import('./utils/generatePdf');
                const fileName = `Rescisao_${formData.empregado.nomeCompleto.replace(/\s+/g, '_') || 'Empregado'}_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`;
                const phone = formData.empregador.telefone
                  ? '55' + formData.empregador.telefone.replace(/\D/g, '')
                  : '5584998226048';
                await shareViaWhatsApp('pdf-content', fileName, phone);
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-green-600 text-white font-semibold hover:bg-green-500 transition-colors"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              Salvar PDF e Enviar ao Escritório
            </button>
          </div>

          {/* WhatsApp direct contact */}
          <div className="mt-6 pt-5 border-t border-gray-100 text-center">
            <p className="text-sm text-gray-500 mb-3">Ou entre em contato diretamente:</p>
            <div className="flex flex-wrap gap-3 justify-center">
              <a
                href="https://wa.me/5584998226048"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-300 rounded-lg text-green-700 text-sm font-medium hover:bg-green-100 transition-colors"
              >
                📱 WhatsApp: (84) 9-9822-6048
              </a>
              <a
                href="https://wa.me/5584988510995"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-300 rounded-lg text-green-700 text-sm font-medium hover:bg-green-100 transition-colors"
              >
                📱 WhatsApp: (84) 9-8851-0995
              </a>
              <a
                href="mailto:medeirosealbuquerqueadv@gmail.com"
                className="flex items-center gap-2 px-4 py-2 bg-blue-50 border border-blue-300 rounded-lg text-blue-700 text-sm font-medium hover:bg-blue-100 transition-colors"
              >
                📧 medeirosealbuquerqueadv@gmail.com
              </a>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="text-center py-6 text-gray-400 text-xs border-t border-gray-200">
          <p className="font-semibold text-gray-600 mb-1">Medeiros & Albuquerque Advogados Associados</p>
          <p>OAB/RN • Natal – Rio Grande do Norte</p>
          <p className="mt-1">
            <a href="https://www.medeirosealbuquerqueadv.com.br" className="text-red-500 hover:text-red-700" target="_blank" rel="noopener noreferrer">
              www.medeirosealbuquerqueadv.com.br
            </a>
          </p>
          <p className="mt-2 text-xs text-gray-300">
            Este formulário contém informações confidenciais de natureza jurídica. Uso restrito ao escritório e seus clientes.
          </p>
        </footer>
      </main>
    </div>
  );
}

export default App;
