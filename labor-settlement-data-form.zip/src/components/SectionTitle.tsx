import React from 'react';

interface SectionTitleProps {
  icon: string;
  title: string;
  subtitle?: string;
}

const SectionTitle: React.FC<SectionTitleProps> = ({ icon, title, subtitle }) => {
  return (
    <div className="flex items-center gap-3 mb-6 pb-3 border-b-2 border-red-700">
      <span className="text-2xl">{icon}</span>
      <div>
        <h2 className="text-lg font-bold text-gray-800 uppercase tracking-wide" style={{ fontFamily: 'Merriweather, serif' }}>
          {title}
        </h2>
        {subtitle && <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>}
      </div>
    </div>
  );
};

export default SectionTitle;
