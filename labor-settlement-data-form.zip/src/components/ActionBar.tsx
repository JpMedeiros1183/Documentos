import React, { useState } from 'react';
import { downloadPDF, shareViaWhatsApp } from '../utils/generatePdf';

interface ActionBarProps {
  onSave: () => void;
  onLoad: () => void;
  onClear: () => void;
  hasSavedData: boolean;
  empregadorTelefone?: string;
  empregadoNome?: string;
}

const ActionBar: React.FC<ActionBarProps> = ({
  onSave,
  onLoad,
  onClear,
  hasSavedData,
  empregadorTelefone,
  empregadoNome,
}) => {
  const [loading, setLoading] = useState(false);
  const [loadingWA, setLoadingWA] = useState(false);
  const [success, setSuccess] = useState('');

  const handleDownload = async () => {
    setLoading(true);
    setSuccess('');
    try {
      const fileName = `Rescisao_${empregadoNome?.replace(/\s+/g, '_') || 'Empregado'}_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`;
      await downloadPDF('pdf-content', fileName);
      setSuccess('PDF salvo com sucesso!');
      setTimeout(() => setSuccess(''), 4000);
    } catch (e) {
      alert('Erro ao gerar PDF. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleWhatsApp = async () => {
    setLoadingWA(true);
    setSuccess('');
    try {
      const fileName = `Rescisao_${empregadoNome?.replace(/\s+/g, '_') || 'Empregado'}_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`;
      const phone = empregadorTelefone
        ? '55' + empregadorTelefone.replace(/\D/g, '')
        : '5584998226048';
      await shareViaWhatsApp('pdf-content', fileName, phone);
      setSuccess('PDF salvo! WhatsApp aberto para envio.');
      setTimeout(() => setSuccess(''), 6000);
    } catch (e) {
      alert('Erro ao gerar PDF. Tente novamente.');
    } finally {
      setLoadingWA(false);
    }
  };

  return (
    <div className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-md">
      <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Left: data management */}
        <div className="flex items-center gap-2">
          <button
            onClick={onSave}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-800 text-white text-sm font-medium hover:bg-gray-700 transition-colors"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
              <path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z" />
            </svg>
            Salvar no Dispositivo
          </button>

          {hasSavedData && (
            <button
              onClick={onLoad}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-medium hover:bg-blue-500 transition-colors"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
              </svg>
              Carregar Dados Salvos
            </button>
          )}

          <button
            onClick={onClear}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-100 text-gray-600 text-sm font-medium hover:bg-gray-200 transition-colors"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-gray-600">
              <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
            </svg>
            Limpar
          </button>
        </div>

        {/* Right: export */}
        <div className="flex items-center gap-2">
          {success && (
            <span className="text-green-600 text-sm font-medium bg-green-50 border border-green-200 px-3 py-1.5 rounded-lg">
              ✅ {success}
            </span>
          )}

          <button
            onClick={handleDownload}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-700 text-white text-sm font-semibold hover:bg-red-600 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="white" strokeWidth="4" />
                  <path className="opacity-75" fill="white" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Gerando PDF...
              </>
            ) : (
              <>
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
                  <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" />
                </svg>
                Baixar PDF
              </>
            )}
          </button>

          <button
            onClick={handleWhatsApp}
            disabled={loadingWA}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-600 text-white text-sm font-semibold hover:bg-green-500 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loadingWA ? (
              <>
                <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="white" strokeWidth="4" />
                  <path className="opacity-75" fill="white" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Preparando...
              </>
            ) : (
              <>
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                Salvar e Enviar ao Escritório
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActionBar;
