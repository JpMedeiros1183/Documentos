import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Input, Select } from '../FormField';
import { DadosEmpregado } from '../../types/formTypes';

interface Props {
  data: DadosEmpregado;
  onChange: (field: keyof DadosEmpregado, value: string) => void;
}

const estadosBrasil = [
  'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'
].map(s => ({ value: s, label: s }));

const estadosCivis = [
  { value: 'solteiro', label: 'Solteiro(a)' },
  { value: 'casado', label: 'Casado(a)' },
  { value: 'divorciado', label: 'Divorciado(a)' },
  { value: 'viuvo', label: 'Viúvo(a)' },
  { value: 'uniao_estavel', label: 'União Estável' },
  { value: 'separado', label: 'Separado(a)' },
];

const grausInstrucao = [
  { value: 'analfabeto', label: 'Analfabeto' },
  { value: 'fundamental_incompleto', label: 'Fundamental Incompleto' },
  { value: 'fundamental_completo', label: 'Fundamental Completo' },
  { value: 'medio_incompleto', label: 'Médio Incompleto' },
  { value: 'medio_completo', label: 'Médio Completo' },
  { value: 'superior_incompleto', label: 'Superior Incompleto' },
  { value: 'superior_completo', label: 'Superior Completo' },
  { value: 'pos_graduacao', label: 'Pós-Graduação' },
];

const SecaoEmpregado: React.FC<Props> = ({ data, onChange }) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="👨‍🌾" title="II – Dados do Empregado (Vaqueiro)" subtitle="Informações pessoais e documentação do trabalhador" />

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Dados Pessoais
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="Nome Completo" required className="lg:col-span-2">
            <Input
              type="text"
              value={data.nomeCompleto}
              onChange={e => onChange('nomeCompleto', e.target.value)}
              placeholder="Nome completo do empregado"
            />
          </FormField>

          <FormField label="CPF" required>
            <Input
              type="text"
              value={data.cpf}
              onChange={e => onChange('cpf', e.target.value)}
              placeholder="000.000.000-00"
            />
          </FormField>

          <FormField label="RG">
            <Input
              type="text"
              value={data.rg}
              onChange={e => onChange('rg', e.target.value)}
              placeholder="Número do RG"
            />
          </FormField>

          <FormField label="Órgão Expedidor / UF">
            <Input
              type="text"
              value={data.orgaoExpedidor}
              onChange={e => onChange('orgaoExpedidor', e.target.value)}
              placeholder="Ex: SSP/RN"
            />
          </FormField>

          <FormField label="Data de Expedição do RG">
            <Input
              type="date"
              value={data.dataExpedicaoRg}
              onChange={e => onChange('dataExpedicaoRg', e.target.value)}
            />
          </FormField>

          <FormField label="Data de Nascimento" required>
            <Input
              type="date"
              value={data.dataNascimento}
              onChange={e => onChange('dataNascimento', e.target.value)}
            />
          </FormField>

          <FormField label="Estado Civil">
            <Select
              value={data.estadoCivil}
              onChange={e => onChange('estadoCivil', e.target.value)}
              options={estadosCivis}
              placeholder="Selecione..."
            />
          </FormField>

          <FormField label="Nacionalidade">
            <Input
              type="text"
              value={data.nacionalidade}
              onChange={e => onChange('nacionalidade', e.target.value)}
              placeholder="Brasileira"
            />
          </FormField>

          <FormField label="Naturalidade (Cidade/UF)">
            <Input
              type="text"
              value={data.naturalidade}
              onChange={e => onChange('naturalidade', e.target.value)}
              placeholder="Ex: Natal/RN"
            />
          </FormField>

          <FormField label="Grau de Instrução">
            <Select
              value={data.grauInstrucao}
              onChange={e => onChange('grauInstrucao', e.target.value)}
              options={grausInstrucao}
              placeholder="Selecione..."
            />
          </FormField>

          <FormField label="Possui Dependentes?">
            <Select
              value={data.possuiDependentes}
              onChange={e => onChange('possuiDependentes', e.target.value)}
              options={[
                { value: 'nao', label: 'Não' },
                { value: 'sim', label: 'Sim' },
              ]}
            />
          </FormField>

          {data.possuiDependentes === 'sim' && (
            <FormField label="Número de Dependentes">
              <Input
                type="number"
                min="0"
                value={data.numeroDependentes}
                onChange={e => onChange('numeroDependentes', e.target.value)}
                placeholder="Ex: 2"
              />
            </FormField>
          )}
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Documentação Trabalhista
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="CTPS – Número" required>
            <Input
              type="text"
              value={data.ctps}
              onChange={e => onChange('ctps', e.target.value)}
              placeholder="Número da CTPS"
            />
          </FormField>

          <FormField label="CTPS – Série">
            <Input
              type="text"
              value={data.ctpsSerie}
              onChange={e => onChange('ctpsSerie', e.target.value)}
              placeholder="Série"
            />
          </FormField>

          <FormField label="CTPS – UF">
            <Select
              value={data.ctpsUf}
              onChange={e => onChange('ctpsUf', e.target.value)}
              options={estadosBrasil}
              placeholder="UF"
            />
          </FormField>

          <FormField label="PIS / PASEP" required>
            <Input
              type="text"
              value={data.pis}
              onChange={e => onChange('pis', e.target.value)}
              placeholder="Número do PIS"
            />
          </FormField>

          <FormField label="Título de Eleitor">
            <Input
              type="text"
              value={data.tituloEleitor}
              onChange={e => onChange('tituloEleitor', e.target.value)}
              placeholder="Número do Título"
            />
          </FormField>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Endereço Residencial
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="CEP">
            <Input
              type="text"
              value={data.enderecoCep}
              onChange={e => onChange('enderecoCep', e.target.value)}
              placeholder="00000-000"
            />
          </FormField>

          <FormField label="Logradouro" className="lg:col-span-2">
            <Input
              type="text"
              value={data.enderecoRua}
              onChange={e => onChange('enderecoRua', e.target.value)}
              placeholder="Rua, Sítio, Localidade..."
            />
          </FormField>

          <FormField label="Número">
            <Input
              type="text"
              value={data.enderecoNumero}
              onChange={e => onChange('enderecoNumero', e.target.value)}
              placeholder="S/N"
            />
          </FormField>

          <FormField label="Complemento">
            <Input
              type="text"
              value={data.enderecoComplemento}
              onChange={e => onChange('enderecoComplemento', e.target.value)}
              placeholder="Casa, Zona Rural..."
            />
          </FormField>

          <FormField label="Bairro / Localidade">
            <Input
              type="text"
              value={data.enderecoBairro}
              onChange={e => onChange('enderecoBairro', e.target.value)}
              placeholder="Bairro ou Localidade"
            />
          </FormField>

          <FormField label="Cidade" required>
            <Input
              type="text"
              value={data.enderecoCidade}
              onChange={e => onChange('enderecoCidade', e.target.value)}
              placeholder="Cidade"
            />
          </FormField>

          <FormField label="Estado">
            <Select
              value={data.enderecoEstado}
              onChange={e => onChange('enderecoEstado', e.target.value)}
              options={estadosBrasil}
            />
          </FormField>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Contato
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Telefone / WhatsApp" required>
            <Input
              type="tel"
              value={data.telefone}
              onChange={e => onChange('telefone', e.target.value)}
              placeholder="(84) 99999-9999"
            />
          </FormField>

          <FormField label="E-mail">
            <Input
              type="email"
              value={data.email}
              onChange={e => onChange('email', e.target.value)}
              placeholder="email@exemplo.com"
            />
          </FormField>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Dados Bancários (para pagamento das verbas rescisórias)
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FormField label="Banco">
            <Input
              type="text"
              value={data.banco}
              onChange={e => onChange('banco', e.target.value)}
              placeholder="Nome do Banco"
            />
          </FormField>

          <FormField label="Agência">
            <Input
              type="text"
              value={data.agencia}
              onChange={e => onChange('agencia', e.target.value)}
              placeholder="0000-0"
            />
          </FormField>

          <FormField label="Conta Corrente">
            <Input
              type="text"
              value={data.contaBancaria}
              onChange={e => onChange('contaBancaria', e.target.value)}
              placeholder="00000-0"
            />
          </FormField>
        </div>
      </div>
    </section>
  );
};

export default SecaoEmpregado;
