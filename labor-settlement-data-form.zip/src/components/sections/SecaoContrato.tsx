import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Input, Select } from '../FormField';
import { DadosContratoTrabalho } from '../../types/formTypes';

interface Props {
  data: DadosContratoTrabalho;
  onChange: (field: keyof DadosContratoTrabalho, value: string) => void;
}

const tiposRescisao = [
  { value: 'dispensa_sem_justa_causa', label: 'Dispensa sem Justa Causa (pelo empregador)' },
  { value: 'dispensa_com_justa_causa', label: 'Dispensa com Justa Causa' },
  { value: 'pedido_demissao', label: 'Pedido de Demissão (pelo empregado)' },
  { value: 'rescisao_indireta', label: 'Rescisão Indireta (falta grave do empregador)' },
  { value: 'acordo_mutuo', label: 'Acordo Mútuo (Art. 484-A CLT)' },
  { value: 'termino_contrato', label: 'Término de Contrato por Prazo Determinado' },
  { value: 'morte_empregado', label: 'Falecimento do Empregado' },
  { value: 'aposentadoria', label: 'Aposentadoria Espontânea' },
];

const SecaoContrato: React.FC<Props> = ({ data, onChange }) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="📋" title="III – Dados do Contrato de Trabalho" subtitle="Informações sobre o vínculo empregatício" />

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Vínculo Empregatício
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="Função / Cargo" required>
            <Input
              type="text"
              value={data.funcao}
              onChange={e => onChange('funcao', e.target.value)}
              placeholder="Ex: Vaqueiro, Tratador de Bovinos"
            />
          </FormField>

          <FormField label="Data de Admissão" required>
            <Input
              type="date"
              value={data.dataAdmissao}
              onChange={e => onChange('dataAdmissao', e.target.value)}
            />
          </FormField>

          <FormField label="Data Prevista do Desligamento" required>
            <Input
              type="date"
              value={data.dataAfastamento}
              onChange={e => onChange('dataAfastamento', e.target.value)}
            />
          </FormField>

          <FormField label="Tipo de Contrato">
            <Select
              value={data.tipoContrato}
              onChange={e => onChange('tipoContrato', e.target.value)}
              options={[
                { value: 'indeterminado', label: 'Prazo Indeterminado' },
                { value: 'determinado', label: 'Prazo Determinado' },
                { value: 'temporario', label: 'Trabalho Temporário' },
                { value: 'safra', label: 'Contrato de Safra' },
              ]}
            />
          </FormField>

          {data.tipoContrato === 'determinado' && (
            <FormField label="Data de Término do Contrato">
              <Input
                type="date"
                value={data.dataTerminoContrato}
                onChange={e => onChange('dataTerminoContrato', e.target.value)}
              />
            </FormField>
          )}

          <FormField label="CTPS Registrada?">
            <Select
              value={data.registradoCTPS}
              onChange={e => onChange('registradoCTPS', e.target.value)}
              options={[
                { value: 'sim', label: 'Sim – registrado em CTPS' },
                { value: 'nao', label: 'Não – sem registro' },
                { value: 'digital', label: 'Sim – CTPS Digital (eSocial)' },
              ]}
            />
          </FormField>

          {data.registradoCTPS !== 'nao' && (
            <FormField label="Data do Registro na CTPS">
              <Input
                type="date"
                value={data.dataRegistroCTPS}
                onChange={e => onChange('dataRegistroCTPS', e.target.value)}
              />
            </FormField>
          )}

          <FormField label="Regime Previdenciário">
            <Select
              value={data.regimePrevid}
              onChange={e => onChange('regimePrevid', e.target.value)}
              options={[
                { value: 'INSS', label: 'INSS – Segurado Empregado' },
                { value: 'INSS_rural', label: 'INSS – Empregado Rural' },
                { value: 'nao_recolhido', label: 'Não recolhido' },
              ]}
            />
          </FormField>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Jornada de Trabalho
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <FormField label="Horas por Dia">
            <Input
              type="number"
              min="1"
              max="24"
              value={data.jornadaTrabalhoHoras}
              onChange={e => onChange('jornadaTrabalhoHoras', e.target.value)}
              placeholder="8"
            />
          </FormField>

          <FormField label="Minutos (complemento)">
            <Select
              value={data.jornadaTrabalhoMinutos}
              onChange={e => onChange('jornadaTrabalhoMinutos', e.target.value)}
              options={[
                { value: '00', label: '00 min' },
                { value: '20', label: '20 min' },
                { value: '30', label: '30 min' },
                { value: '40', label: '40 min' },
              ]}
            />
          </FormField>

          <FormField label="Dias Trabalhados por Semana">
            <Select
              value={data.diasTrabalhadosSemana}
              onChange={e => onChange('diasTrabalhadosSemana', e.target.value)}
              options={[
                { value: '5', label: '5 dias (seg a sex)' },
                { value: '5.5', label: '5,5 dias (seg a sáb meio dia)' },
                { value: '6', label: '6 dias (seg a sáb)' },
                { value: '7', label: '7 dias (todos os dias)' },
              ]}
            />
          </FormField>

          <FormField label="Tipo de Salário">
            <Select
              value={data.tipoSalario}
              onChange={e => onChange('tipoSalario', e.target.value)}
              options={[
                { value: 'mensal', label: 'Mensal' },
                { value: 'quinzenal', label: 'Quinzenal' },
                { value: 'semanal', label: 'Semanal' },
                { value: 'diario', label: 'Diário' },
                { value: 'por_producao', label: 'Por Produção / Tarefa' },
              ]}
            />
          </FormField>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Motivo da Rescisão
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 gap-4">
          <FormField label="Tipo de Rescisão / Motivo do Desligamento" required>
            <Select
              value={data.motivoRescisao}
              onChange={e => onChange('motivoRescisao', e.target.value)}
              options={tiposRescisao}
              placeholder="Selecione o tipo de rescisão..."
            />
          </FormField>

          {data.motivoRescisao && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <span className="text-amber-600 text-lg">⚖️</span>
                <div>
                  <p className="text-sm font-semibold text-amber-800">Observação Jurídica:</p>
                  {data.motivoRescisao === 'dispensa_sem_justa_causa' && (
                    <p className="text-sm text-amber-700">Gera direito a: aviso prévio, 13º salário proporcional, férias proporcionais + 1/3, saldo de salário, multa de 40% do FGTS, e saque do FGTS. Seguro-desemprego se couber.</p>
                  )}
                  {data.motivoRescisao === 'dispensa_com_justa_causa' && (
                    <p className="text-sm text-amber-700">Gera direito a: saldo de salário e férias vencidas (se houver). Não há aviso prévio, 13º proporcional, multa do FGTS nem saque do FGTS.</p>
                  )}
                  {data.motivoRescisao === 'pedido_demissao' && (
                    <p className="text-sm text-amber-700">Gera direito a: saldo de salário, 13º proporcional, férias proporcionais + 1/3. Sem multa do FGTS. Aviso prévio pode ser indenizado pelo empregado.</p>
                  )}
                  {data.motivoRescisao === 'acordo_mutuo' && (
                    <p className="text-sm text-amber-700">Art. 484-A CLT: Aviso prévio de 50%, 13º proporcional, férias proporcionais + 1/3, saldo de salário, multa de 20% do FGTS, saque de 80% do FGTS. Não tem seguro-desemprego.</p>
                  )}
                  {data.motivoRescisao === 'rescisao_indireta' && (
                    <p className="text-sm text-amber-700">Equivale à dispensa sem justa causa para fins de verbas. O empregado deve provar a falta grave do empregador perante a Justiça do Trabalho.</p>
                  )}
                  {data.motivoRescisao === 'termino_contrato' && (
                    <p className="text-sm text-amber-700">Gera direito a: saldo de salário, 13º proporcional, férias proporcionais + 1/3, indenização adicional (50% dos salários restantes se rescisão antecipada).</p>
                  )}
                  {data.motivoRescisao === 'aposentadoria' && (
                    <p className="text-sm text-amber-700">Aposentadoria espontânea não extingue o contrato por si só. Verifique se há continuidade do vínculo após a concessão do benefício.</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default SecaoContrato;
