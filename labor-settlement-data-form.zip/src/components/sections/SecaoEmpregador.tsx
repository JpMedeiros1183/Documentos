import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Input, Select } from '../FormField';
import { DadosEmpregador } from '../../types/formTypes';

interface Props {
  data: DadosEmpregador;
  onChange: (field: keyof DadosEmpregador, value: string) => void;
}

const estadosBrasil = [
  'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'
].map(s => ({ value: s, label: s }));

const estadosCivis = [
  { value: 'solteiro', label: 'Solteiro(a)' },
  { value: 'casado', label: 'Casado(a)' },
  { value: 'divorciado', label: 'Divorciado(a)' },
  { value: 'viuvo', label: 'Viúvo(a)' },
  { value: 'uniao_estavel', label: 'União Estável' },
  { value: 'separado', label: 'Separado(a)' },
];

const SecaoEmpregador: React.FC<Props> = ({ data, onChange }) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="👩‍🌾" title="I – Dados da Empregadora" subtitle="Informações pessoais e da propriedade rural" />

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Dados Pessoais
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="Nome Completo" required className="lg:col-span-2">
            <Input
              type="text"
              value={data.nomeCompleto}
              onChange={e => onChange('nomeCompleto', e.target.value)}
              placeholder="Nome completo da empregadora"
            />
          </FormField>

          <FormField label="CPF / CNPJ" required>
            <Input
              type="text"
              value={data.cpfCnpj}
              onChange={e => onChange('cpfCnpj', e.target.value)}
              placeholder="000.000.000-00"
            />
          </FormField>

          <FormField label="RG">
            <Input
              type="text"
              value={data.rg}
              onChange={e => onChange('rg', e.target.value)}
              placeholder="Número do RG"
            />
          </FormField>

          <FormField label="Data de Nascimento">
            <Input
              type="date"
              value={data.dataNascimento}
              onChange={e => onChange('dataNascimento', e.target.value)}
            />
          </FormField>

          <FormField label="Estado Civil">
            <Select
              value={data.estadoCivil}
              onChange={e => onChange('estadoCivil', e.target.value)}
              options={estadosCivis}
              placeholder="Selecione..."
            />
          </FormField>

          <FormField label="Nacionalidade">
            <Input
              type="text"
              value={data.nacionalidade}
              onChange={e => onChange('nacionalidade', e.target.value)}
              placeholder="Brasileira"
            />
          </FormField>

          <FormField label="Profissão / Ocupação">
            <Input
              type="text"
              value={data.profissao}
              onChange={e => onChange('profissao', e.target.value)}
              placeholder="Ex: Produtora Rural"
            />
          </FormField>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Endereço Residencial
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="CEP">
            <Input
              type="text"
              value={data.enderecoCep}
              onChange={e => onChange('enderecoCep', e.target.value)}
              placeholder="00000-000"
            />
          </FormField>

          <FormField label="Logradouro" className="lg:col-span-2">
            <Input
              type="text"
              value={data.enderecoRua}
              onChange={e => onChange('enderecoRua', e.target.value)}
              placeholder="Rua, Avenida, Travessa..."
            />
          </FormField>

          <FormField label="Número">
            <Input
              type="text"
              value={data.enderecoNumero}
              onChange={e => onChange('enderecoNumero', e.target.value)}
              placeholder="Nº"
            />
          </FormField>

          <FormField label="Complemento">
            <Input
              type="text"
              value={data.enderecoComplemento}
              onChange={e => onChange('enderecoComplemento', e.target.value)}
              placeholder="Apto, Sala..."
            />
          </FormField>

          <FormField label="Bairro">
            <Input
              type="text"
              value={data.enderecoBairro}
              onChange={e => onChange('enderecoBairro', e.target.value)}
              placeholder="Bairro"
            />
          </FormField>

          <FormField label="Cidade" required>
            <Input
              type="text"
              value={data.enderecoCidade}
              onChange={e => onChange('enderecoCidade', e.target.value)}
              placeholder="Cidade"
            />
          </FormField>

          <FormField label="Estado">
            <Select
              value={data.enderecoEstado}
              onChange={e => onChange('enderecoEstado', e.target.value)}
              options={estadosBrasil}
            />
          </FormField>
        </div>
      </div>

      <div className="mb-4">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Contato
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Telefone / WhatsApp" required>
            <Input
              type="tel"
              value={data.telefone}
              onChange={e => onChange('telefone', e.target.value)}
              placeholder="(84) 99999-9999"
            />
          </FormField>

          <FormField label="E-mail">
            <Input
              type="email"
              value={data.email}
              onChange={e => onChange('email', e.target.value)}
              placeholder="email@exemplo.com.br"
            />
          </FormField>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Dados da Propriedade Rural
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <FormField label="Nome da Propriedade / Sítio" required>
            <Input
              type="text"
              value={data.nomePropriedade}
              onChange={e => onChange('nomePropriedade', e.target.value)}
              placeholder="Ex: Sítio São José"
            />
          </FormField>

          <FormField label="Endereço / Localização" className="lg:col-span-2">
            <Input
              type="text"
              value={data.enderecoPropriedade}
              onChange={e => onChange('enderecoPropriedade', e.target.value)}
              placeholder="Localidade, zona rural, município"
            />
          </FormField>

          <FormField label="Área Total (hectares)">
            <Input
              type="text"
              value={data.areaTotalHectares}
              onChange={e => onChange('areaTotalHectares', e.target.value)}
              placeholder="Ex: 50 ha"
            />
          </FormField>

          <FormField label="Tipo de Atividade Principal">
            <Input
              type="text"
              value={data.tipoAtividade}
              onChange={e => onChange('tipoAtividade', e.target.value)}
              placeholder="Ex: Pecuária leiteira"
            />
          </FormField>

          <FormField label="Inscrição Estadual Rural">
            <Input
              type="text"
              value={data.inscricaoEstadualRural}
              onChange={e => onChange('inscricaoEstadualRural', e.target.value)}
              placeholder="Número da inscrição"
            />
          </FormField>

          <FormField label="CAEPF" hint="Cadastro de Atividade Econômica da Pessoa Física">
            <Input
              type="text"
              value={data.caepf}
              onChange={e => onChange('caepf', e.target.value)}
              placeholder="Nº do CAEPF"
            />
          </FormField>
        </div>
      </div>
    </section>
  );
};

export default SecaoEmpregador;
