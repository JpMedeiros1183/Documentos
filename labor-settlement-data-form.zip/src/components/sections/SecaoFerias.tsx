import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Input, Select, Checkbox } from '../FormField';
import { DadosFerias } from '../../types/formTypes';

interface Props {
  data: DadosFerias;
  onChange: (field: keyof DadosFerias, value: string | boolean) => void;
}

const SecaoFerias: React.FC<Props> = ({ data, onChange }) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="🌴" title="VI – Férias e 13º Salário" subtitle="Períodos aquisitivos e gozo de férias" />

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <p className="text-sm text-blue-800">
          <strong>ℹ️ Importante:</strong> Informe os dados sobre férias para que o escritório possa calcular corretamente as férias vencidas, proporcionais e o terço constitucional (1/3).
          O trabalhador rural tem direito a 30 dias de férias após cada período aquisitivo de 12 meses.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <FormField label="Início do Último Período Aquisitivo" hint="Data em que o empregado completou 1 ano de trabalho ou início do período atual">
          <Input
            type="date"
            value={data.ultimoPeriodoAquisitivo}
            onChange={e => onChange('ultimoPeriodoAquisitivo', e.target.value)}
          />
        </FormField>
      </div>

      <div className="space-y-4 mb-6">
        <div className="border border-gray-200 rounded-xl p-4">
          <Checkbox
            label="Empregado já gozou férias em algum período"
            checked={data.feriasGozadas}
            onChange={v => onChange('feriasGozadas', v)}
          />
          {data.feriasGozadas && (
            <div className="mt-3 ml-7 grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField label="Data de Início das Últimas Férias Gozadas">
                <Input
                  type="date"
                  value={data.dataInicioFerias}
                  onChange={e => onChange('dataInicioFerias', e.target.value)}
                />
              </FormField>
              <FormField label="Data de Término das Últimas Férias Gozadas">
                <Input
                  type="date"
                  value={data.dataFimFerias}
                  onChange={e => onChange('dataFimFerias', e.target.value)}
                />
              </FormField>
            </div>
          )}
        </div>

        <div className="border border-gray-200 rounded-xl p-4">
          <Checkbox
            label="Há férias proporcionais a receber (período incompleto)"
            checked={data.feriasProporcional}
            onChange={v => onChange('feriasProporcional', v)}
          />
          {data.feriasProporcional && (
            <div className="mt-3 ml-7">
              <FormField label="Quantos meses do período proporcional?">
                <Select
                  value={data.mesesProporcional}
                  onChange={e => onChange('mesesProporcional', e.target.value)}
                  options={Array.from({ length: 11 }, (_, i) => ({
                    value: String(i + 1),
                    label: `${i + 1} ${i + 1 === 1 ? 'mês' : 'meses'}`
                  }))}
                  placeholder="Selecione..."
                  className="max-w-xs"
                />
              </FormField>
            </div>
          )}
        </div>

        <div className="border border-gray-200 rounded-xl p-4">
          <Checkbox
            label="Empregado optou por converter 1/3 das férias em abono pecuniário (vender 10 dias)"
            checked={data.terecoDeFerias}
            onChange={v => onChange('terecoDeFerias', v)}
          />
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-sm text-amber-800 font-semibold mb-1">⚖️ Lembrete – Verbas Rescisórias a Calcular pelo Escritório:</p>
        <ul className="text-sm text-amber-700 space-y-1 list-disc list-inside">
          <li>Saldo de salário dos dias trabalhados no mês da rescisão</li>
          <li>Aviso prévio (trabalhado ou indenizado)</li>
          <li>13º salário proporcional</li>
          <li>Férias vencidas + 1/3 (se houver)</li>
          <li>Férias proporcionais + 1/3</li>
          <li>FGTS sobre todo o período + multa de 40% (dispensa imotivada)</li>
          <li>Indenização adicional (se cabível – art. 9º, Lei 7.238/84)</li>
        </ul>
      </div>
    </section>
  );
};

export default SecaoFerias;
