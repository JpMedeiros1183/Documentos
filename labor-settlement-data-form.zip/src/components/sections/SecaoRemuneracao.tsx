import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Input, Select, Checkbox } from '../FormField';
import { DadosRemuneracao } from '../../types/formTypes';

interface Props {
  data: DadosRemuneracao;
  onChange: (field: keyof DadosRemuneracao, value: string | boolean) => void;
}

const SecaoRemuneracao: React.FC<Props> = ({ data, onChange }) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="💰" title="IV – Remuneração e Benefícios" subtitle="Salário base e todos os adicionais percebidos" />

      <div className="mb-6">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Salário Base
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Salário Base (R$)" required hint="Informe o último salário antes da rescisão">
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-semibold">R$</span>
              <Input
                type="number"
                step="0.01"
                min="0"
                value={data.salarioBase}
                onChange={e => onChange('salarioBase', e.target.value)}
                placeholder="0,00"
                className="pl-10"
              />
            </div>
          </FormField>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-2">
            <span className="text-blue-600">ℹ️</span>
            <p className="text-xs text-blue-700">
              <strong>Salário Mínimo 2025:</strong> R$ 1.518,00 | <strong>Mínimo Rural RN:</strong> Verificar convenção coletiva da categoria.
            </p>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Adicionais e Gratificações
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>

        <div className="space-y-4">
          {/* Insalubridade */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Adicional de Insalubridade"
              checked={data.recebeAdicionalInsalubridade}
              onChange={v => onChange('recebeAdicionalInsalubridade', v)}
            />
            {data.recebeAdicionalInsalubridade && (
              <div className="mt-3 ml-7">
                <FormField label="Grau de Insalubridade">
                  <Select
                    value={data.grauInsalubridade}
                    onChange={e => onChange('grauInsalubridade', e.target.value)}
                    options={[
                      { value: 'minimo', label: 'Mínimo – 10% do salário mínimo' },
                      { value: 'medio', label: 'Médio – 20% do salário mínimo' },
                      { value: 'maximo', label: 'Máximo – 40% do salário mínimo' },
                    ]}
                    placeholder="Selecione o grau..."
                    className="max-w-xs"
                  />
                </FormField>
              </div>
            )}
          </div>

          {/* Periculosidade */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Adicional de Periculosidade (30% sobre o salário)"
              checked={data.recebeAdicionalPericulosidade}
              onChange={v => onChange('recebeAdicionalPericulosidade', v)}
            />
          </div>

          {/* Horas Extras */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Realiza Horas Extras habitualmente"
              checked={data.recebeHorasExtras}
              onChange={v => onChange('recebeHorasExtras', v)}
            />
            {data.recebeHorasExtras && (
              <div className="mt-3 ml-7 grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField label="Percentual de Horas Extras">
                  <Select
                    value={data.percentualHorasExtras}
                    onChange={e => onChange('percentualHorasExtras', e.target.value)}
                    options={[
                      { value: '50', label: '50% (dias úteis)' },
                      { value: '100', label: '100% (domingos e feriados)' },
                      { value: '75', label: '75% (acordo coletivo)' },
                    ]}
                  />
                </FormField>
                <FormField label="Média de Horas Extras / Mês">
                  <Input
                    type="number"
                    min="0"
                    value={data.mediaHorasExtrasMes}
                    onChange={e => onChange('mediaHorasExtrasMes', e.target.value)}
                    placeholder="Ex: 20"
                  />
                </FormField>
              </div>
            )}
          </div>

          {/* Adicional Noturno */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Adicional Noturno (trabalho entre 22h e 5h)"
              checked={data.recebeAdicionalNoturno}
              onChange={v => onChange('recebeAdicionalNoturno', v)}
            />
          </div>

          {/* Comissões */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Comissões ou percentual sobre produção de leite"
              checked={data.recebeComissoes}
              onChange={v => onChange('recebeComissoes', v)}
            />
            {data.recebeComissoes && (
              <div className="mt-3 ml-7">
                <FormField label="Média de Comissões / Mês (R$)">
                  <div className="relative max-w-xs">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-semibold">R$</span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={data.mediaComissoesMes}
                      onChange={e => onChange('mediaComissoesMes', e.target.value)}
                      placeholder="0,00"
                      className="pl-10"
                    />
                  </div>
                </FormField>
              </div>
            )}
          </div>

          {/* Gratificações */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Gratificações ou premiações habituais"
              checked={data.recebeGratificacoes}
              onChange={v => onChange('recebeGratificacoes', v)}
            />
            {data.recebeGratificacoes && (
              <div className="mt-3 ml-7">
                <FormField label="Descreva as gratificações">
                  <Input
                    type="text"
                    value={data.descricaoGratificacoes}
                    onChange={e => onChange('descricaoGratificacoes', e.target.value)}
                    placeholder="Ex: Gratificação por produtividade de R$ 200/mês"
                  />
                </FormField>
              </div>
            )}
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Benefícios e Utilidades (In Natura)
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <p className="text-xs text-gray-500 mb-4 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          ⚠️ <strong>Atenção:</strong> Utilidades fornecidas pelo empregador rural (alimentação, habitação) podem integrar o salário para fins de cálculo das verbas rescisórias (art. 9º, Lei 5.889/73). Informe todos os benefícios.
        </p>
        <div className="space-y-4">
          {/* Alimentação */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Alimentação / Rancho fornecido pelo empregador"
              checked={data.recebeAlimentacao}
              onChange={v => onChange('recebeAlimentacao', v)}
            />
            {data.recebeAlimentacao && (
              <div className="mt-3 ml-7">
                <FormField label="Valor estimado / mês (R$)">
                  <div className="relative max-w-xs">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-semibold">R$</span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={data.alimentacaoValor}
                      onChange={e => onChange('alimentacaoValor', e.target.value)}
                      placeholder="0,00"
                      className="pl-10"
                    />
                  </div>
                </FormField>
              </div>
            )}
          </div>

          {/* Habitação */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Habitação / Moradia no sítio"
              checked={data.recebeHabitacao}
              onChange={v => onChange('recebeHabitacao', v)}
            />
            {data.recebeHabitacao && (
              <div className="mt-3 ml-7">
                <FormField label="Valor estimado / mês (R$)">
                  <div className="relative max-w-xs">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-semibold">R$</span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={data.habitacaoValor}
                      onChange={e => onChange('habitacaoValor', e.target.value)}
                      placeholder="0,00"
                      className="pl-10"
                    />
                  </div>
                </FormField>
              </div>
            )}
          </div>

          {/* Transporte */}
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Recebe Transporte fornecido pelo empregador"
              checked={data.recebeTransporte}
              onChange={v => onChange('recebeTransporte', v)}
            />
            {data.recebeTransporte && (
              <div className="mt-3 ml-7">
                <FormField label="Valor estimado / mês (R$)">
                  <div className="relative max-w-xs">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-semibold">R$</span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={data.transporteValor}
                      onChange={e => onChange('transporteValor', e.target.value)}
                      placeholder="0,00"
                      className="pl-10"
                    />
                  </div>
                </FormField>
              </div>
            )}
          </div>

          <FormField label="Outros adicionais ou benefícios não listados acima">
            <Input
              type="text"
              value={data.outrosAdicionais}
              onChange={e => onChange('outrosAdicionais', e.target.value)}
              placeholder="Descreva outros benefícios, se houver..."
            />
          </FormField>
        </div>
      </div>
    </section>
  );
};

export default SecaoRemuneracao;
