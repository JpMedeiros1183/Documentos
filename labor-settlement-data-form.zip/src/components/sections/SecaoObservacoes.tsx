import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Textarea, Input } from '../FormField';

interface Props {
  observacoes: string;
  dataPreenchimento: string;
  onChangeObservacoes: (value: string) => void;
  onChangeData: (value: string) => void;
}

const SecaoObservacoes: React.FC<Props> = ({
  observacoes,
  dataPreenchimento,
  onChangeObservacoes,
  onChangeData,
}) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="📝" title="VII – Observações e Informações Adicionais" subtitle="Informações relevantes não contempladas nos campos anteriores" />

      <div className="space-y-4">
        <FormField
          label="Observações Gerais"
          hint="Inclua aqui quaisquer informações adicionais que possam ser relevantes para o cálculo das verbas rescisórias ou para o acordo judicial."
        >
          <Textarea
            value={observacoes}
            onChange={e => onChangeObservacoes(e.target.value)}
            rows={6}
            placeholder="Ex: O empregado trabalhava sem registro; havia acordo verbal de pagamento de comissão por litro de leite; existência de dívidas entre as partes; histórico de advertências; acidentes de trabalho; atestados médicos; etc."
          />
        </FormField>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Data de Preenchimento deste Formulário">
            <Input
              type="date"
              value={dataPreenchimento}
              onChange={e => onChangeData(e.target.value)}
            />
          </FormField>
        </div>

        {/* Termo de compromisso */}
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-5 mt-4">
          <p className="text-sm font-bold text-gray-700 mb-2">⚠️ Declaração do Informante:</p>
          <p className="text-sm text-gray-600 leading-relaxed">
            Declaro que as informações prestadas neste formulário são verdadeiras e foram fornecidas para fins de orientação jurídica e elaboração de acordo rescisório trabalhista junto ao escritório
            <strong> Medeiros & Albuquerque Advogados</strong>. Estou ciente de que omissões ou informações incorretas podem prejudicar o processo de elaboração do acordo judicial.
          </p>
        </div>

        {/* Signature fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
          <div className="text-center">
            <div className="border-b-2 border-gray-800 mb-2 pt-10"></div>
            <p className="text-sm font-semibold text-gray-700">Assinatura da Empregadora</p>
            <p className="text-xs text-gray-500">Nome / CPF</p>
          </div>
          <div className="text-center">
            <div className="border-b-2 border-gray-800 mb-2 pt-10"></div>
            <p className="text-sm font-semibold text-gray-700">Assinatura do Empregado</p>
            <p className="text-xs text-gray-500">Nome / CPF</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecaoObservacoes;
