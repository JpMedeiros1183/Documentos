import React from 'react';
import SectionTitle from '../SectionTitle';
import { FormField, Input, Select, Checkbox, Textarea } from '../FormField';
import { DadosAtividadeRural } from '../../types/formTypes';

interface Props {
  data: DadosAtividadeRural;
  onChange: (field: keyof DadosAtividadeRural, value: string | boolean) => void;
}

const SecaoAtividadeRural: React.FC<Props> = ({ data, onChange }) => {
  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
      <SectionTitle icon="🐄" title="V – Atividades Exercidas no Trabalho Rural" subtitle="Detalhamento das funções e condições de trabalho no sítio" />

      <div className="mb-6">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Local e Condições de Trabalho
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Local Específico de Trabalho" className="md:col-span-2">
            <Input
              type="text"
              value={data.localTrabalho}
              onChange={e => onChange('localTrabalho', e.target.value)}
              placeholder="Ex: Curral, Pasto, Lavoura, Área de Ordenha..."
            />
          </FormField>

          <FormField label="Descrição Detalhada das Atividades" className="md:col-span-2">
            <Textarea
              value={data.descricaoAtividades}
              onChange={e => onChange('descricaoAtividades', e.target.value)}
              rows={4}
              placeholder="Descreva todas as tarefas realizadas pelo empregado: trato dos animais, ordenha, limpeza do curral, alimentação do gado, manutenção de cercas, etc."
            />
          </FormField>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Trato com Animais e Ordenha
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="space-y-4">
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Trabalha com animais (bovinos, equinos, suínos, etc.)"
              checked={data.trabalhaComAnimais}
              onChange={v => onChange('trabalhaComAnimais', v)}
            />
            {data.trabalhaComAnimais && (
              <div className="mt-3 ml-7 grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField label="Tipo de Animais">
                  <Input
                    type="text"
                    value={data.tipoAnimais}
                    onChange={e => onChange('tipoAnimais', e.target.value)}
                    placeholder="Ex: Bovinos (vacas leiteiras), Equinos..."
                  />
                </FormField>
                <FormField label="Número aproximado de animais sob seus cuidados">
                  <Input
                    type="text"
                    value={data.numeroAnimais}
                    onChange={e => onChange('numeroAnimais', e.target.value)}
                    placeholder="Ex: 30 vacas"
                  />
                </FormField>
              </div>
            )}
          </div>

          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Realiza ordenha (manual ou mecânica)"
              checked={data.realizaOrdenha}
              onChange={v => onChange('realizaOrdenha', v)}
            />
            {data.realizaOrdenha && (
              <div className="mt-3 ml-7">
                <FormField label="Frequência da Ordenha">
                  <Input
                    type="text"
                    value={data.frequenciaOrdenha}
                    onChange={e => onChange('frequenciaOrdenha', e.target.value)}
                    placeholder="Ex: Duas vezes ao dia, às 5h e 15h"
                  />
                </FormField>
              </div>
            )}
          </div>

          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Realiza trato e alimentação dos animais"
              checked={data.realizaTratoAnimais}
              onChange={v => onChange('realizaTratoAnimais', v)}
            />
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Equipamentos e Riscos
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="space-y-4">
          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Utiliza maquinário / equipamentos (trator, ordenhadeira mecânica, etc.)"
              checked={data.utilizaMaquinario}
              onChange={v => onChange('utilizaMaquinario', v)}
            />
            {data.utilizaMaquinario && (
              <div className="mt-3 ml-7">
                <FormField label="Descreva os equipamentos utilizados">
                  <Input
                    type="text"
                    value={data.descricaoMaquinario}
                    onChange={e => onChange('descricaoMaquinario', e.target.value)}
                    placeholder="Ex: Trator, ordenhadeira mecânica, moto..."
                  />
                </FormField>
              </div>
            )}
          </div>

          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Trabalha com agrotóxicos / defensivos agrícolas"
              checked={data.trabalhaComAgrotoxicos}
              onChange={v => onChange('trabalhaComAgrotoxicos', v)}
            />
          </div>

          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Utiliza EPI – Equipamento de Proteção Individual"
              checked={data.utilizaEPI}
              onChange={v => onChange('utilizaEPI', v)}
            />
            {data.utilizaEPI && (
              <div className="mt-3 ml-7">
                <FormField label="Quais EPIs são fornecidos?">
                  <Input
                    type="text"
                    value={data.descricaoEPI}
                    onChange={e => onChange('descricaoEPI', e.target.value)}
                    placeholder="Ex: Luvas, botas, máscara..."
                  />
                </FormField>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-bold text-red-700 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-6 h-px bg-red-300 inline-block"></span>
          Jornada, Intervalos e Acomodação
          <span className="flex-1 h-px bg-red-100 inline-block"></span>
        </h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border border-gray-200 rounded-xl p-4">
              <Checkbox
                label="Trabalha aos finais de semana"
                checked={data.trabalhaFinalDeSemana}
                onChange={v => onChange('trabalhaFinalDeSemana', v)}
              />
            </div>

            <div className="border border-gray-200 rounded-xl p-4">
              <Checkbox
                label="Trabalha nos feriados"
                checked={data.trabalhaFeriados}
                onChange={v => onChange('trabalhaFeriados', v)}
              />
            </div>

            <div className="border border-gray-200 rounded-xl p-4">
              <Checkbox
                label="Possui intervalo para repouso / alimentação (intrajornada)"
                checked={data.temIntervaloPara}
                onChange={v => onChange('temIntervaloPara', v)}
              />
            </div>
          </div>

          {data.temIntervaloPara && (
            <div className="ml-4">
              <FormField label="Duração do Intervalo">
                <Select
                  value={data.duracaoIntervaloPara}
                  onChange={e => onChange('duracaoIntervaloPara', e.target.value)}
                  options={[
                    { value: '15min', label: '15 minutos' },
                    { value: '30min', label: '30 minutos' },
                    { value: '1h', label: '1 hora' },
                    { value: '1h30', label: '1 hora e 30 minutos' },
                    { value: '2h', label: '2 horas' },
                  ]}
                  placeholder="Selecione..."
                  className="max-w-xs"
                />
              </FormField>
            </div>
          )}

          <div className="border border-gray-200 rounded-xl p-4">
            <Checkbox
              label="Reside / possui acomodação no local de trabalho (sítio)"
              checked={data.possuiAcomodacao}
              onChange={v => onChange('possuiAcomodacao', v)}
            />
            {data.possuiAcomodacao && (
              <div className="mt-3 ml-7">
                <FormField label="Descreva a acomodação">
                  <Input
                    type="text"
                    value={data.descricaoAcomodacao}
                    onChange={e => onChange('descricaoAcomodacao', e.target.value)}
                    placeholder="Ex: Casa de alvenaria no sítio, com água e energia elétrica"
                  />
                </FormField>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecaoAtividadeRural;
