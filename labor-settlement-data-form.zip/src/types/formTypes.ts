export interface DadosEmpregador {
  nomeCompleto: string;
  cpfCnpj: string;
  rg: string;
  dataNascimento: string;
  estadoCivil: string;
  nacionalidade: string;
  profissao: string;
  enderecoRua: string;
  enderecoNumero: string;
  enderecoComplemento: string;
  enderecoBairro: string;
  enderecoCidade: string;
  enderecoEstado: string;
  enderecoCep: string;
  telefone: string;
  email: string;
  // Dados da propriedade rural
  nomePropriedade: string;
  enderecoPropriedade: string;
  areaTotalHectares: string;
  tipoAtividade: string;
  inscricaoEstadualRural: string;
  caepf: string; // Cadastro de Atividade Econômica da Pessoa Física
}

export interface DadosEmpregado {
  nomeCompleto: string;
  cpf: string;
  rg: string;
  orgaoExpedidor: string;
  dataExpedicaoRg: string;
  dataNascimento: string;
  estadoCivil: string;
  nacionalidade: string;
  naturalidade: string;
  enderecoRua: string;
  enderecoNumero: string;
  enderecoComplemento: string;
  enderecoBairro: string;
  enderecoCidade: string;
  enderecoEstado: string;
  enderecoCep: string;
  telefone: string;
  email: string;
  ctps: string;
  ctpsSerie: string;
  ctpsUf: string;
  pis: string;
  tituloEleitor: string;
  grauInstrucao: string;
  possuiDependentes: string;
  numeroDependentes: string;
  contaBancaria: string;
  agencia: string;
  banco: string;
}

export interface DadosContratoTrabalho {
  dataAdmissao: string;
  dataAfastamento: string; // data prevista da demissão
  funcao: string;
  salarioBase: string;
  tipoSalario: string; // mensal, quinzenal, diário, por produção
  jornadaTrabalhoHoras: string;
  jornadaTrabalhoMinutos: string;
  diasTrabalhadosSemana: string;
  tipoContrato: string; // prazo indeterminado, prazo determinado, temporário
  dataTerminoContrato: string; // se prazo determinado
  motivoRescisao: string; // tipo de desligamento
  registradoCTPS: string;
  dataRegistroCTPS: string;
  regimePrevid: string; // INSS
}

export interface DadosRemuneracao {
  salarioBase: string;
  recebeAdicionalInsalubridade: boolean;
  grauInsalubridade: string; // mínimo, médio, máximo
  recebeAdicionalPericulosidade: boolean;
  recebeHorasExtras: boolean;
  percentualHorasExtras: string;
  mediaHorasExtrasMes: string;
  recebeAdicionalNoturno: boolean;
  recebeComissoes: boolean;
  mediaComissoesMes: string;
  recebeGratificacoes: boolean;
  descricaoGratificacoes: string;
  recebeAlimentacao: boolean;
  alimentacaoValor: string;
  recebeHabitacao: boolean;
  habitacaoValor: string;
  recebeTransporte: boolean;
  transporteValor: string;
  outrosAdicionais: string;
}

export interface DadosAtividadeRural {
  descricaoAtividades: string;
  trabalhaComAnimais: boolean;
  tipoAnimais: string;
  numeroAnimais: string;
  realizaOrdenha: boolean;
  frequenciaOrdenha: string;
  realizaTratoAnimais: boolean;
  utilizaMaquinario: boolean;
  descricaoMaquinario: string;
  trabalhaComAgrotoxicos: boolean;
  utilizaEPI: boolean;
  descricaoEPI: string;
  localTrabalho: string;
  trabalhaFinalDeSemana: boolean;
  trabalhaFeriados: boolean;
  temIntervaloPara: boolean;
  duracaoIntervaloPara: string;
  possuiAcomodacao: boolean;
  descricaoAcomodacao: string;
}

export interface DadosFerias {
  ultimoPeriodoAquisitivo: string;
  feriasGozadas: boolean;
  dataInicioFerias: string;
  dataFimFerias: string;
  feriasProporcional: boolean;
  mesesProporcional: string;
  terecoDeFerias: boolean;
}

export interface FormData {
  empregador: DadosEmpregador;
  empregado: DadosEmpregado;
  contrato: DadosContratoTrabalho;
  remuneracao: DadosRemuneracao;
  atividadeRural: DadosAtividadeRural;
  ferias: DadosFerias;
  observacoesGerais: string;
  dataPreenchimento: string;
}
