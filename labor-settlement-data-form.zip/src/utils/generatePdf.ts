import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export const generatePDF = async (elementId: string): Promise<Blob> => {
  const element = document.getElementById(elementId);
  if (!element) throw new Error('Elemento não encontrado');

  const canvas = await html2canvas(element, {
    scale: 1.8,
    useCORS: true,
    logging: false,
    backgroundColor: '#f8f9fa',
    windowWidth: 1200,
  });

  const imgData = canvas.toDataURL('image/jpeg', 0.92);
  const pdf = new jsPDF('p', 'mm', 'a4');

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  const imgWidth = pageWidth;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 0;

  pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
  heightLeft -= pageHeight;

  while (heightLeft > 0) {
    position = heightLeft - imgHeight;
    pdf.addPage();
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
  }

  return pdf.output('blob');
};

export const downloadPDF = async (elementId: string, fileName: string) => {
  const blob = await generatePDF(elementId);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const shareViaWhatsApp = async (elementId: string, fileName: string, phone: string = '5584998226048') => {
  const blob = await generatePDF(elementId);

  // Save the PDF first
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  // Then open WhatsApp
  setTimeout(() => {
    const message = encodeURIComponent(
      `Olá, Dr(a)! Segue em anexo a Ficha de Dados para Rescisão de Contrato de Trabalho Rural. Por favor, verifique o PDF que foi salvo no meu dispositivo. 📎`
    );
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  }, 1000);
};
